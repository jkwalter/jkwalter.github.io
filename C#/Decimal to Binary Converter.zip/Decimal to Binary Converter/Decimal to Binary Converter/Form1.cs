﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Decimal_to_Binary_Converter
{
    public partial class MainScreen : Form
    {
        public MainScreen()
        {
            InitializeComponent();
        }

        private void CalculateButton_Click(object sender, EventArgs e)
        {
            int DecimalNumber;
            List<int> List = new List<int>();
            String BinaryNumber = null;

            DecimalNumber = (int)DecimalInput.Value;

            //Algorithm to Convert Decimal Numbers to Binary
            if (DecimalNumber == 0)
            {
                List.Add(DecimalNumber);
            }
            else
            {
                while (DecimalNumber != 0)
                {
                    List.Add(DecimalNumber % 2);
                    DecimalNumber = DecimalNumber / 2;
                }
            }
            List.Reverse();

            //Display List Contents to the Screen
            foreach(int Digit in List)
            {
                BinaryNumber = BinaryNumber + Digit.ToString();
            }

            OutputLabel.Text = BinaryNumber;

            //Clear List in Case User Clicks CalculateButton Again
            List.Clear();
            BinaryNumber = null;

            ClearButton.Focus();
        }

        private void ClearButton_Click(object sender, EventArgs e)
        {
            //Reset the Program
            DecimalInput.Value = 0;
            OutputLabel.Text = null;

            DecimalInput.Focus();
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            //Exit the Program
            Close();
        }

        private void DecimalInput_Enter(object sender, EventArgs e)
        {
            NumericUpDown InputBox = sender as NumericUpDown;

            //Clear Output and Select Contents of NumericUpDown Field upon Entering Focus
            OutputLabel.Text = null;
            InputBox.Select(0, InputBox.Value.ToString().Length);
        }

        private void DecimalInput_Leave(object sender, EventArgs e)
        {
            NumericUpDown InputBox = sender as NumericUpDown;

            //Display Contents of NumericUpDown Field upon Leaving Focus
            InputBox.Text = InputBox.Value.ToString();
        }
    }
}