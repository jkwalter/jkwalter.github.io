﻿namespace Decimal_to_Binary_Converter
{
    partial class MainScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TitleLabel = new System.Windows.Forms.Label();
            this.DecimalInput = new System.Windows.Forms.NumericUpDown();
            this.DecimalLabel = new System.Windows.Forms.Label();
            this.BinaryLabel = new System.Windows.Forms.Label();
            this.OutputLabel = new System.Windows.Forms.Label();
            this.CalculateButton = new System.Windows.Forms.Button();
            this.ClearButton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.DecimalInput)).BeginInit();
            this.SuspendLayout();
            // 
            // TitleLabel
            // 
            this.TitleLabel.AutoSize = true;
            this.TitleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.TitleLabel.Location = new System.Drawing.Point(25, 9);
            this.TitleLabel.Name = "TitleLabel";
            this.TitleLabel.Size = new System.Drawing.Size(285, 26);
            this.TitleLabel.TabIndex = 0;
            this.TitleLabel.Text = "Decimal to Binary Converter";
            // 
            // DecimalInput
            // 
            this.DecimalInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.DecimalInput.Location = new System.Drawing.Point(226, 74);
            this.DecimalInput.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.DecimalInput.Name = "DecimalInput";
            this.DecimalInput.Size = new System.Drawing.Size(70, 26);
            this.DecimalInput.TabIndex = 2;
            this.DecimalInput.Click += new System.EventHandler(this.DecimalInput_Enter);
            this.DecimalInput.Enter += new System.EventHandler(this.DecimalInput_Enter);
            this.DecimalInput.Leave += new System.EventHandler(this.DecimalInput_Leave);
            // 
            // DecimalLabel
            // 
            this.DecimalLabel.AutoSize = true;
            this.DecimalLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.DecimalLabel.Location = new System.Drawing.Point(36, 76);
            this.DecimalLabel.Name = "DecimalLabel";
            this.DecimalLabel.Size = new System.Drawing.Size(184, 20);
            this.DecimalLabel.TabIndex = 1;
            this.DecimalLabel.Text = "Decimal Representation:";
            // 
            // BinaryLabel
            // 
            this.BinaryLabel.AutoSize = true;
            this.BinaryLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.BinaryLabel.Location = new System.Drawing.Point(36, 124);
            this.BinaryLabel.Name = "BinaryLabel";
            this.BinaryLabel.Size = new System.Drawing.Size(140, 20);
            this.BinaryLabel.TabIndex = 3;
            this.BinaryLabel.Text = "Binary Conversion:";
            // 
            // OutputLabel
            // 
            this.OutputLabel.AutoSize = true;
            this.OutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.OutputLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.OutputLabel.Location = new System.Drawing.Point(182, 124);
            this.OutputLabel.MaximumSize = new System.Drawing.Size(114, 22);
            this.OutputLabel.MinimumSize = new System.Drawing.Size(114, 22);
            this.OutputLabel.Name = "OutputLabel";
            this.OutputLabel.Size = new System.Drawing.Size(114, 22);
            this.OutputLabel.TabIndex = 4;
            // 
            // CalculateButton
            // 
            this.CalculateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.CalculateButton.Location = new System.Drawing.Point(12, 199);
            this.CalculateButton.Name = "CalculateButton";
            this.CalculateButton.Size = new System.Drawing.Size(95, 50);
            this.CalculateButton.TabIndex = 5;
            this.CalculateButton.Text = "Calculate";
            this.CalculateButton.UseVisualStyleBackColor = true;
            this.CalculateButton.Click += new System.EventHandler(this.CalculateButton_Click);
            // 
            // ClearButton
            // 
            this.ClearButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.ClearButton.Location = new System.Drawing.Point(120, 199);
            this.ClearButton.Name = "ClearButton";
            this.ClearButton.Size = new System.Drawing.Size(95, 50);
            this.ClearButton.TabIndex = 6;
            this.ClearButton.Text = "Clear";
            this.ClearButton.UseVisualStyleBackColor = true;
            this.ClearButton.Click += new System.EventHandler(this.ClearButton_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.ExitButton.Location = new System.Drawing.Point(227, 199);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(95, 50);
            this.ExitButton.TabIndex = 7;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // MainScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(334, 261);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.ClearButton);
            this.Controls.Add(this.CalculateButton);
            this.Controls.Add(this.OutputLabel);
            this.Controls.Add(this.BinaryLabel);
            this.Controls.Add(this.DecimalLabel);
            this.Controls.Add(this.DecimalInput);
            this.Controls.Add(this.TitleLabel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "MainScreen";
            this.Text = "Decimal to Binary Converter";
            ((System.ComponentModel.ISupportInitialize)(this.DecimalInput)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label TitleLabel;
        private System.Windows.Forms.NumericUpDown DecimalInput;
        private System.Windows.Forms.Label DecimalLabel;
        private System.Windows.Forms.Label BinaryLabel;
        private System.Windows.Forms.Label OutputLabel;
        private System.Windows.Forms.Button CalculateButton;
        private System.Windows.Forms.Button ClearButton;
        private System.Windows.Forms.Button ExitButton;
    }
}

