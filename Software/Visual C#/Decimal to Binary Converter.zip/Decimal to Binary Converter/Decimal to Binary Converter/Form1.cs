﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Decimal_to_Binary_Converter
{
    public partial class MainScreen : Form
    {
        public MainScreen()
        {
            InitializeComponent();
        }

        private void CalculateButton_Click(object sender, EventArgs e)
        {
            int decimal_number;
            List<int> list = new List<int>();
            String binary_number = null;

            decimal_number = Convert.ToInt32(DecimalInput.Value);

            if (decimal_number == 0)
            {
                list.Add(decimal_number);
            }
            else
            {
                while (decimal_number != 0)
                {
                    list.Add(decimal_number % 2);
                    decimal_number = decimal_number / 2;
                }
            }

            list.Reverse();

            foreach(int digit in list)
            {
                binary_number = binary_number + Convert.ToString(digit);
            }

            OutputLabel.Text = binary_number;

            list.Clear();
            ClearButton.Select();
        }

        private void ClearButton_Click(object sender, EventArgs e)
        {
            DecimalInput.Text = "0";
            OutputLabel.Text = "";
            DecimalInput.Select();
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void DecimalInput_Enter(object sender, EventArgs e)
        {
            NumericUpDown InputBox = sender as NumericUpDown;

            OutputLabel.Text = null;

            if (InputBox != null)
            {
                InputBox.Select(0, InputBox.Value.ToString().Length);
            }
        }

        private void DecimalInput_Leave(object sender, EventArgs e)
        {
            NumericUpDown InputBox = sender as NumericUpDown;

            if (InputBox.Text == "")
            {
                MessageBox.Show("Please enter a number.", "Decimal to Binary Converter", MessageBoxButtons.OK, MessageBoxIcon.Error);
                DecimalInput.Text = "0";
                DecimalInput.Select();
            }
        }
    }
}