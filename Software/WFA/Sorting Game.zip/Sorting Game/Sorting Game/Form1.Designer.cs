﻿namespace Sorting_Game
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TitleLabel = new System.Windows.Forms.Label();
            this.Number1 = new System.Windows.Forms.Label();
            this.Number2 = new System.Windows.Forms.Label();
            this.Number3 = new System.Windows.Forms.Label();
            this.Number4 = new System.Windows.Forms.Label();
            this.Number5 = new System.Windows.Forms.Label();
            this.Answer1 = new System.Windows.Forms.NumericUpDown();
            this.Answer2 = new System.Windows.Forms.NumericUpDown();
            this.Answer3 = new System.Windows.Forms.NumericUpDown();
            this.Answer4 = new System.Windows.Forms.NumericUpDown();
            this.Answer5 = new System.Windows.Forms.NumericUpDown();
            this.CheckButton = new System.Windows.Forms.Button();
            this.ResetButton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.Answer1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Answer2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Answer3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Answer4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Answer5)).BeginInit();
            this.SuspendLayout();
            // 
            // TitleLabel
            // 
            this.TitleLabel.AutoSize = true;
            this.TitleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.TitleLabel.Location = new System.Drawing.Point(100, 25);
            this.TitleLabel.MaximumSize = new System.Drawing.Size(505, 35);
            this.TitleLabel.MinimumSize = new System.Drawing.Size(505, 35);
            this.TitleLabel.Name = "TitleLabel";
            this.TitleLabel.Size = new System.Drawing.Size(505, 35);
            this.TitleLabel.TabIndex = 0;
            this.TitleLabel.Text = "Arrange Numbers from Least to Greatest";
            // 
            // Number1
            // 
            this.Number1.AutoSize = true;
            this.Number1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Number1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.Number1.Location = new System.Drawing.Point(105, 90);
            this.Number1.MaximumSize = new System.Drawing.Size(50, 50);
            this.Number1.MinimumSize = new System.Drawing.Size(50, 50);
            this.Number1.Name = "Number1";
            this.Number1.Size = new System.Drawing.Size(50, 50);
            this.Number1.TabIndex = 1;
            this.Number1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Number2
            // 
            this.Number2.AutoSize = true;
            this.Number2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Number2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.Number2.Location = new System.Drawing.Point(215, 90);
            this.Number2.MaximumSize = new System.Drawing.Size(50, 50);
            this.Number2.MinimumSize = new System.Drawing.Size(50, 50);
            this.Number2.Name = "Number2";
            this.Number2.Size = new System.Drawing.Size(50, 50);
            this.Number2.TabIndex = 2;
            this.Number2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Number3
            // 
            this.Number3.AutoSize = true;
            this.Number3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Number3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.Number3.Location = new System.Drawing.Point(325, 90);
            this.Number3.MaximumSize = new System.Drawing.Size(50, 50);
            this.Number3.MinimumSize = new System.Drawing.Size(50, 50);
            this.Number3.Name = "Number3";
            this.Number3.Size = new System.Drawing.Size(50, 50);
            this.Number3.TabIndex = 3;
            this.Number3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Number4
            // 
            this.Number4.AutoSize = true;
            this.Number4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Number4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.Number4.Location = new System.Drawing.Point(435, 90);
            this.Number4.MaximumSize = new System.Drawing.Size(50, 50);
            this.Number4.MinimumSize = new System.Drawing.Size(50, 50);
            this.Number4.Name = "Number4";
            this.Number4.Size = new System.Drawing.Size(50, 50);
            this.Number4.TabIndex = 4;
            this.Number4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Number5
            // 
            this.Number5.AutoSize = true;
            this.Number5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Number5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.Number5.Location = new System.Drawing.Point(545, 90);
            this.Number5.MaximumSize = new System.Drawing.Size(50, 50);
            this.Number5.MinimumSize = new System.Drawing.Size(50, 50);
            this.Number5.Name = "Number5";
            this.Number5.Size = new System.Drawing.Size(50, 50);
            this.Number5.TabIndex = 5;
            this.Number5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Answer1
            // 
            this.Answer1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.Answer1.Location = new System.Drawing.Point(105, 175);
            this.Answer1.Maximum = new decimal(new int[] {
            9,
            0,
            0,
            0});
            this.Answer1.MaximumSize = new System.Drawing.Size(50, 0);
            this.Answer1.MinimumSize = new System.Drawing.Size(50, 0);
            this.Answer1.Name = "Answer1";
            this.Answer1.Size = new System.Drawing.Size(50, 38);
            this.Answer1.TabIndex = 6;
            this.Answer1.Tag = "";
            this.Answer1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Answer1.Click += new System.EventHandler(this.NumericUpDown_Enter);
            this.Answer1.Enter += new System.EventHandler(this.NumericUpDown_Enter);
            this.Answer1.Leave += new System.EventHandler(this.NumericUpDown_Leave);
            // 
            // Answer2
            // 
            this.Answer2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.Answer2.Location = new System.Drawing.Point(215, 175);
            this.Answer2.Maximum = new decimal(new int[] {
            9,
            0,
            0,
            0});
            this.Answer2.MaximumSize = new System.Drawing.Size(50, 0);
            this.Answer2.MinimumSize = new System.Drawing.Size(50, 0);
            this.Answer2.Name = "Answer2";
            this.Answer2.Size = new System.Drawing.Size(50, 38);
            this.Answer2.TabIndex = 7;
            this.Answer2.Tag = "";
            this.Answer2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Answer2.Click += new System.EventHandler(this.NumericUpDown_Enter);
            this.Answer2.Enter += new System.EventHandler(this.NumericUpDown_Enter);
            this.Answer2.Leave += new System.EventHandler(this.NumericUpDown_Leave);
            // 
            // Answer3
            // 
            this.Answer3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.Answer3.Location = new System.Drawing.Point(325, 175);
            this.Answer3.Maximum = new decimal(new int[] {
            9,
            0,
            0,
            0});
            this.Answer3.MaximumSize = new System.Drawing.Size(50, 0);
            this.Answer3.MinimumSize = new System.Drawing.Size(50, 0);
            this.Answer3.Name = "Answer3";
            this.Answer3.Size = new System.Drawing.Size(50, 38);
            this.Answer3.TabIndex = 8;
            this.Answer3.Tag = "";
            this.Answer3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Answer3.Click += new System.EventHandler(this.NumericUpDown_Enter);
            this.Answer3.Enter += new System.EventHandler(this.NumericUpDown_Enter);
            this.Answer3.Leave += new System.EventHandler(this.NumericUpDown_Leave);
            // 
            // Answer4
            // 
            this.Answer4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.Answer4.Location = new System.Drawing.Point(435, 175);
            this.Answer4.Maximum = new decimal(new int[] {
            9,
            0,
            0,
            0});
            this.Answer4.MaximumSize = new System.Drawing.Size(50, 0);
            this.Answer4.MinimumSize = new System.Drawing.Size(50, 0);
            this.Answer4.Name = "Answer4";
            this.Answer4.Size = new System.Drawing.Size(50, 38);
            this.Answer4.TabIndex = 9;
            this.Answer4.Tag = "";
            this.Answer4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Answer4.Click += new System.EventHandler(this.NumericUpDown_Enter);
            this.Answer4.Enter += new System.EventHandler(this.NumericUpDown_Enter);
            this.Answer4.Leave += new System.EventHandler(this.NumericUpDown_Leave);
            // 
            // Answer5
            // 
            this.Answer5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.Answer5.Location = new System.Drawing.Point(545, 175);
            this.Answer5.Maximum = new decimal(new int[] {
            9,
            0,
            0,
            0});
            this.Answer5.MaximumSize = new System.Drawing.Size(50, 0);
            this.Answer5.MinimumSize = new System.Drawing.Size(50, 0);
            this.Answer5.Name = "Answer5";
            this.Answer5.Size = new System.Drawing.Size(50, 38);
            this.Answer5.TabIndex = 10;
            this.Answer5.Tag = "";
            this.Answer5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Answer5.Click += new System.EventHandler(this.NumericUpDown_Enter);
            this.Answer5.Enter += new System.EventHandler(this.NumericUpDown_Enter);
            this.Answer5.Leave += new System.EventHandler(this.NumericUpDown_Leave);
            // 
            // CheckButton
            // 
            this.CheckButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.CheckButton.Location = new System.Drawing.Point(120, 275);
            this.CheckButton.Name = "CheckButton";
            this.CheckButton.Size = new System.Drawing.Size(130, 55);
            this.CheckButton.TabIndex = 11;
            this.CheckButton.Text = "Check";
            this.CheckButton.UseVisualStyleBackColor = true;
            this.CheckButton.Click += new System.EventHandler(this.CheckButton_Click);
            // 
            // ResetButton
            // 
            this.ResetButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.ResetButton.Location = new System.Drawing.Point(285, 275);
            this.ResetButton.Name = "ResetButton";
            this.ResetButton.Size = new System.Drawing.Size(130, 55);
            this.ResetButton.TabIndex = 12;
            this.ResetButton.Text = "Reset";
            this.ResetButton.UseVisualStyleBackColor = true;
            this.ResetButton.Click += new System.EventHandler(this.ResetButton_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.ExitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.ExitButton.Location = new System.Drawing.Point(450, 275);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(130, 55);
            this.ExitButton.TabIndex = 13;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // Main
            // 
            this.AcceptButton = this.CheckButton;
            this.CancelButton = this.ExitButton;
            this.ClientSize = new System.Drawing.Size(684, 361);
            this.Controls.Add(this.Answer5);
            this.Controls.Add(this.Answer4);
            this.Controls.Add(this.Answer3);
            this.Controls.Add(this.Answer2);
            this.Controls.Add(this.Answer1);
            this.Controls.Add(this.Number5);
            this.Controls.Add(this.Number4);
            this.Controls.Add(this.Number3);
            this.Controls.Add(this.Number2);
            this.Controls.Add(this.Number1);
            this.Controls.Add(this.TitleLabel);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.ResetButton);
            this.Controls.Add(this.CheckButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Main";
            this.Text = "Sorting Game";
            ((System.ComponentModel.ISupportInitialize)(this.Answer1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Answer2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Answer3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Answer4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Answer5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }


        #endregion

        private System.Windows.Forms.Button CheckButton;
        private System.Windows.Forms.Button ResetButton;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.Label TitleLabel;
        private System.Windows.Forms.Label Number1;
        private System.Windows.Forms.Label Number2;
        private System.Windows.Forms.Label Number3;
        private System.Windows.Forms.Label Number4;
        private System.Windows.Forms.Label Number5;
        private System.Windows.Forms.NumericUpDown Answer1;
        private System.Windows.Forms.NumericUpDown Answer2;
        private System.Windows.Forms.NumericUpDown Answer3;
        private System.Windows.Forms.NumericUpDown Answer4;
        private System.Windows.Forms.NumericUpDown Answer5;
    }
}

