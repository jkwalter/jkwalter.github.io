﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sorting_Game
{
    public partial class Main : Form
    {
        List<int> List = new List<int>();
        List<int> Answers = new List<int>();

        void AssignList(List<int> List)
        {
            int Counter;
            Random Generate = new Random();

            //Generate Random Numbers and Append to List
            for (Counter = 0; Counter < 5; Counter++)
            {
                List.Add(Generate.Next(0, 9));
            }

            //Display List to Screen
            Number1.Text = List[0].ToString();
            Number2.Text = List[1].ToString();
            Number3.Text = List[2].ToString();
            Number4.Text = List[3].ToString();
            Number5.Text = List[4].ToString();

            //Sort the List
            List.Sort();
        }

        public Main()
        {
            InitializeComponent();

            //Generate List of Random Numbers for User to Sort
            AssignList(List);
        }

        private void CheckButton_Click(object sender, EventArgs e)
        {
            int Counter;
            bool Correct = true;

            //Append User's Answers to a List
            Answers.Add((int)Answer1.Value);
            Answers.Add((int)Answer2.Value);
            Answers.Add((int)Answer3.Value);
            Answers.Add((int)Answer4.Value);
            Answers.Add((int)Answer5.Value);

            //Compare User's Answers to Sorted List
            for (Counter = 0; Counter < 5; Counter++)
            {
                if (List[Counter] != Answers[Counter])
                {
                    Correct = false;
                }
            }

            if (Correct == true)
            {
                //User Wins if Answers Are Correct
                MessageBox.Show("You won!", "Sorting Game", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ResetButton.Focus();
            }
            else
            {
                //Try Again if User Is Incorrect
                MessageBox.Show("Sorry! Try again!", "Sorting Game", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                Answer1.Focus();
            }

            //Clear User's Answers in Case User Clicks CheckButton Again
            Answers.Clear();
        }

        private void ResetButton_Click(object sender, EventArgs e)
        {
            DialogResult Result;
            
            Result = MessageBox.Show("Are you sure?", "Sorting Game", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (Result == DialogResult.Yes)
            {
                //Reset the Program
                List.Clear();

                AssignList(List);

                Answer1.Value = 0;
                Answer2.Value = 0;
                Answer3.Value = 0;
                Answer4.Value = 0;
                Answer5.Value = 0;

                Answer1.Focus();
            }
            else
            {
                ExitButton.Focus();
            }
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            //Exit the Program
            Close();
        }

        private void NumericUpDown_Enter(object sender, EventArgs e)
        {
            NumericUpDown Answer = sender as NumericUpDown;

            //Select Contents of NumericUpDown Field upon Entering Focus
            Answer.Select(0, Answer.Value.ToString().Length);
        }

        private void NumericUpDown_Leave(object sender, EventArgs e)
        {
            NumericUpDown Answer = sender as NumericUpDown;

            //Display Contents of NumericUpDown Field upon Leaving Focus
            Answer.Text = Answer.Value.ToString();
        }
    }
}